import machine
import time
# ----------------------------------
# Función: indicador de estado del programa
# Enciende el LED interno de la Raspberry Pico
# para indicar que el programa está en ejecución
# ----------------------------------
led = machine.Pin("LED", machine.Pin.OUT)
led.value(1)  # LED encendido permanente
# ----------------------------------
# Función: configuración de comunicación UART
# Permite enviar datos al ESP32
# TX = GP0
# RX = GP1
# Velocidad = 9600 baudios
# ----------------------------------
uart = machine.UART(0, baudrate=9600, tx=machine.Pin(0), rx=machine.Pin(1))
# ----------------------------------
# Función: configuración de sensores infrarrojos
# Se definen los pines de entrada para los sensores
# ----------------------------------
s_izq = machine.Pin(14, machine.Pin.IN)
s_cen = machine.Pin(13, machine.Pin.IN)
s_der = machine.Pin(15, machine.Pin.IN)
# ----------------------------------
# Función: parámetros del controlador PID
# Ajustan el comportamiento del robot
# ----------------------------------
Kp = 60          # Ganancia proporcional (fuerza de corrección)
Ki = 0           # Ganancia integral (error acumulado)
Kd = 25          # Ganancia derivativa (estabilidad)

velocidad_base = 130  # Velocidad base del robot
# Variables de control del PID
error_previo = 0
integral = 0

print("Robot Listo: Negro detectado como 0 (LED sensor apagado)")
# ----------------------------------
# Bucle principal del programa
# Se ejecuta continuamente
# ----------------------------------
while True:
    # ----------------------------------
    # Función: lectura de sensores
    # Obtiene los valores digitales de los sensores
    # ----------------------------------
    izq = s_izq.value()
    cen = s_cen.value()
    der = s_der.value()
    # ----------------------------------
    # Función: cálculo del error de posición
    # Determina hacia qué lado se desvió el robot
    # ----------------------------------
    if   izq == 0 and cen == 1 and der == 1:
        error = -2  # línea a la izquierda
    
    elif izq == 0 and cen == 0 and der == 1:
        error = -1  # ligeramente a la izquierda
    
    elif izq == 1 and cen == 0 and der == 1:
        error = 0   # centrado
    
    elif izq == 1 and cen == 0 and der == 0:
        error = 1   # ligeramente a la derecha
    
    elif izq == 1 and cen == 1 and der == 0:
        error = 2   # línea a la derecha
    # ----------------------------------
    # Función: detección de condiciones especiales
    # ----------------------------------
    elif izq == 1 and cen == 1 and der == 1:
        # Robot perdió la línea
        error = -3 if error_previo < 0 else 3

    elif izq == 0 and cen == 0 and der == 0:
        # Posible intersección
        error = 0

    else:
        error = 0
    # ----------------------------------
    # Función: monitoreo en consola
    # Permite observar el estado de sensores
    # ----------------------------------
    print(f"Sensores: [I:{izq} C:{cen} D:{der}] | Error: {error}")
    # ----------------------------------
    # Función: cálculo del controlador PID
    # Calcula la corrección necesaria
    # ----------------------------------
    P = error
    integral = max(-50, min(50, integral + error))
    D = error - error_previo

    correccion = int((Kp * P) + (Ki * integral) + (Kd * D))

    error_previo = error
    # ----------------------------------
    # Función: cálculo de velocidad de motores
    # Ajusta la velocidad izquierda y derecha
    # ----------------------------------
    v_izq = max(0, min(250, velocidad_base + correccion))
    v_der = max(0, min(250, velocidad_base - correccion))
    # ----------------------------------
    # Función: envío de datos por UART
    # Se envían las velocidades al ESP32
    # ----------------------------------
    uart.write(f"{v_izq},{v_der}\n")
    # ----------------------------------
    # Función: tiempo de muestreo
    # Controla la frecuencia de actualización
    # ----------------------------------
    time.sleep(0.01)