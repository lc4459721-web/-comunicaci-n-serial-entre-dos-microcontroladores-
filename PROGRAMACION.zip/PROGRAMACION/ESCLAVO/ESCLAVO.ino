// -----------------------------
// Definición de pines del driver
// -----------------------------

// Pines del Motor A
const int ENA = 14;  // Pin PWM para controlar velocidad del motor izquierdo
const int IN1 = 27;  // Control de dirección motor A
const int IN2 = 26;  // Control de dirección motor A

// Pines del Motor B
const int ENB = 13;  // Pin PWM para controlar velocidad del motor derecho
const int IN3 = 25;  // Control de dirección motor B
const int IN4 = 33;  // Control de dirección motor B



// -----------------------------
// Función setup()
// Se ejecuta una sola vez al iniciar el microcontrolador
// Aquí se inicializan comunicación y pines
// -----------------------------
void setup() {

  // Inicializa comunicación UART2
  // Velocidad: 9600 baudios
  // RX = GPIO16
  // TX = GPIO17
  Serial2.begin(9600, SERIAL_8N1, 16, 17);

  // Configuración de pines de dirección como salida
  pinMode(IN1, OUTPUT);
  pinMode(IN2, OUTPUT);
  pinMode(IN3, OUTPUT);
  pinMode(IN4, OUTPUT);

  // Configuración del PWM para control de velocidad
  // Frecuencia: 5000 Hz
  // Resolución: 8 bits (0–255)
  ledcAttach(ENA, 5000, 8);
  ledcAttach(ENB, 5000, 8);
}



// -----------------------------
// Función loop()
// Se ejecuta continuamente mientras el ESP32 esté encendido
// Encargada de recibir datos y controlar los motores
// -----------------------------
void loop() {

  // Verifica si hay datos disponibles en el puerto serial
  if (Serial2.available()) {

    // Función: lectura de datos seriales enviados por la Raspberry Pico
    // Lee la cadena hasta encontrar el salto de línea
    String dato = Serial2.readStringUntil('\n');

    // Función: buscar separador de datos
    // La coma separa velocidad izquierda y derecha
    int coma = dato.indexOf(',');

    // Función: validación del formato recibido
    if (coma != -1) {

      // Función: extracción de velocidad del motor izquierdo
      int velIzq = dato.substring(0, coma).toInt();

      // Función: extracción de velocidad del motor derecho
      int velDer = dato.substring(coma + 1).toInt();

      // Función: control de dirección de motores
      // Ambos motores giran hacia adelante
      digitalWrite(IN1, HIGH);
      digitalWrite(IN2, LOW);

      digitalWrite(IN3, HIGH);
      digitalWrite(IN4, LOW);

      // Función: aplicación de velocidad mediante PWM
      // Ajusta velocidad de cada motor
      ledcWrite(ENA, velIzq);
      ledcWrite(ENB, velDer);
    }
  }
}
